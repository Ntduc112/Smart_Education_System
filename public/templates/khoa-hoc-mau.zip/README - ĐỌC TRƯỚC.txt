================================================================
  HƯỚNG DẪN IMPORT KHÓA HỌC TỪ FOLDER
================================================================

Folder này là MẪU. Bạn sao chép cấu trúc, điền nội dung của mình
vào, rồi vào trang chỉnh sửa khóa học > "Import từ folder" để tải lên.

----------------------------------------------------------------
CẤU TRÚC
----------------------------------------------------------------

  <Folder bạn chọn>/
    1. Tên chương/
      1. Tên bài/
        video.mp4        (tùy chọn)
        slide.pdf        (tùy chọn - tài liệu bài học)
        quiz.json        (tùy chọn - đề kiểm tra, xem mẫu)
        quiz.pdf         (tùy chọn - thay quiz.json, AI tự trích đề)
      2. Tên bài tiếp/
        ...
    2. Tên chương tiếp/
      ...

- Cấp 1 = CHƯƠNG. Cấp 2 = BÀI HỌC. File nằm trong folder bài.
- Folder bạn CHỌN khi import = khóa học (đã tạo sẵn trên hệ thống),
  tên của nó không quan trọng.

----------------------------------------------------------------
QUY TẮC TÊN  (BẮT BUỘC)
----------------------------------------------------------------

- Tên CHƯƠNG và BÀI phải bắt đầu bằng SỐ THỨ TỰ:
      "1. Giới thiệu"   "2. Cài đặt"   "3-Tổng kết"
  Dấu phân tách: . - _ ) hoặc dấu cách.
- Số quyết định thứ tự hiển thị. Thiếu số => KHÔNG import được.
- Phần sau số là tên hiển thị của chương/bài.

----------------------------------------------------------------
FILE TRONG MỖI BÀI
----------------------------------------------------------------

- VIDEO : .mp4 .mov .avi .webm   (mỗi bài tối đa 1 video)
- PDF   : slide.pdf hoặc .pdf khác (tài liệu bài học)
- QUIZ  : chọn 1 trong 2 cách bên dưới (không bắt buộc)
- File khác sẽ bị bỏ qua.

----------------------------------------------------------------
QUIZ - CÁCH 1 (DỄ NHẤT): file quiz.pdf
----------------------------------------------------------------

Đặt file đề tên "quiz.pdf" trong folder bài. Đề phải có sẵn câu hỏi
VÀ đáp án (đánh dấu đáp án đúng: in đậm, dấu *, hoặc "Đáp án: B"...).
Hệ thống tự đọc và trích câu hỏi khi import.

- Chỉ nhận PDF có chữ thật (xuất từ Word...), KHÔNG nhận ảnh chụp/scan.
- Nên xem lại quiz sau khi import để chắc chắn đáp án đúng.

----------------------------------------------------------------
QUIZ - CÁCH 2 (CHÍNH XÁC): file quiz.json
----------------------------------------------------------------

Xem mẫu: "1. Chương mở đầu/1. Giới thiệu khóa học/quiz.json".

- "questions": danh sách câu hỏi (bắt buộc).
- "type": MCQ (trắc nghiệm) | TRUE_FALSE (đúng/sai) | SHORT_ANSWER (tự luận).
- MCQ và TRUE_FALSE: cần "options", mỗi đáp án có "is_correct" true/false,
  ít nhất 1 đáp án đúng.
- SHORT_ANSWER: chỉ cần "content", có thể thêm "sample_answer" (gợi ý).
- "title", "pass_score", "points" là tùy chọn (mặc định pass_score=70).

Nếu có cả quiz.json và quiz.pdf, hệ thống ưu tiên quiz.json.
Nếu quiz sai định dạng => bài vẫn được tạo, chỉ bỏ qua quiz.

================================================================
